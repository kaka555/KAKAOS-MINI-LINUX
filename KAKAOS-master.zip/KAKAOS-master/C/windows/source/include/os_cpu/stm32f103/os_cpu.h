#ifndef _CPU_H
#define _CPU_H

#include <os_cpu_stm32.h>

#endif
