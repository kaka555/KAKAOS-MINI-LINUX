#ifndef _SPARSE_MEM_MODULE_H
#define _SPARSE_MEM_MODULE_H

struct mem_section
{

};

#endif