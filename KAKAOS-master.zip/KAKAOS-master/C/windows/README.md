# windows下工程编译步骤
</br>
1.进入Project文件夹，选择对应的工程名称目录，打开keil工程文件</br>
2.配置keil的编译工具为gcc，这一步只需选择gcc可执行文件的目录</br>
3.编译下载</br>