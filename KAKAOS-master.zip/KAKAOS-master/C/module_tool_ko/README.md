# 可重定位动态模块编译模板

## 使用步骤
1.修改KER_DIR以指向内核代码目录</br>
2.根据内核目录下.ka_config文件修改PROJECT</br>
3.根据内核目录下.ka_config文件修改FLAGS</br>
4.根据本地安装gcc的路径修改LIBPATH</br>
5.将src修改为需要编译的文件</br>
6.make
